<?php
// Define la constante DB_HOST con el valor 'localhost'
define('DB_HOST', 'localhost');

// Define la constante DB_USER con el valor 'user_restaurante'
define('DB_USER', 'user_restaurante');

// Define la constante DB_PASSWORD con el valor 'userUSER2'
define('DB_PASSWORD', 'userUSER2');

// Define la constante DB_NAME con el valor 'restaurantexyz'
define('DB_NAME', 'restaurantexyz');
?>
