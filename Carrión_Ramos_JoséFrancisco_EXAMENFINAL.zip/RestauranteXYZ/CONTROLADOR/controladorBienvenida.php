<?php
//Llamo a layoutBienvenida para que me muestre la interfaz que seleccione el rol
include('./VISTA/LAYOUT/layoutBienvenida.php');
?>